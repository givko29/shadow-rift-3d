Shadow Rift: Ascension 3D browser game site

Upload index.html to a GitHub repository, then enable GitHub Pages from Settings > Pages.
The game loads Three.js from a CDN, so players need an internet connection.
